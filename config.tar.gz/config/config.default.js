
exports.appKey = 'You cannot guess if you die';
exports.keys = '20145012';
exports.info = {
  username: 'lindz',
  password: 'lindz',
};
exports.errorHandler = {
  match: '/api',
};
exports.login = {
  match: function(ctx) {
    if (ctx.path === '/api/comment' || ctx.path === '/api/message') {
      const data = ctx.request.body;
      const mailOptions = ctx.app.config.mailOptions;
      if (data.name === mailOptions.name || data.email === mailOptions.email) {
        return true;
      } else {
        return false;
      }
    }
    if (/^\/admin/.test(ctx.path) || /^\/api/.test(ctx.path)) {
      return true;
    }
    return false;
  },
};
exports.mongoose = {
  client: {
    url: 'mongodb://127.0.0.1:27017/blog',
    options: {
      autoIndex: false,
    },
  },
};

exports.multipart = {
  fileExtensions: ['.md'],
};

exports.session = {
  key: 'EGG_SESS',
  maxAge: 24 * 3600 * 1000,
  httpOnly: true,
  encrypt: true,
};

exports.view = {
  mapping: {
    '.html': 'ejs',
  },
  defaultExtension: '.html',
  // root: `${path.resolve(__dirname, '../app/public')},${path.resolve(__dirname, '../app/view')}`,
};


exports.graphql = {
  router: '/graphql',
  app: true,
  agent: false,
  graphiql: true,
};

exports.mailConfig = {
  'host': 'smtp.exmail.qq.com',
  'port': 465,
  'secureConnection': true,
  'auth': {
    'user': 'info@lindongzhou.com',
    'pass': 'Ljr5201996'
  }
};

exports.mailOptions = {
  'email': 'me@lindongzhou.com',
  'name': '博主',
  'content': '',
};
