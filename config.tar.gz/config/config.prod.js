
exports.baseUrl = '//www.lindongzhou.com';
exports.middleware = ['errorHandler', 'login', 'graphql'];