
exports.base_url = 'https://lindongzhou.com';
exports.middleware = ['errorHandler', 'login', 'graphql'];
exports.security = {
  csrf: false,
  ctoken: false,
};