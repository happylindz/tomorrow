
exports.validate = {
  enable: true,
  package: 'egg-validate',
};

exports.mongoose = {
  enable: true,
  package: 'egg-mongoose',
};

exports.ejs = {
  enable: true,
  package: 'egg-view-ejs',
};

exports.graphql = {
  enable: true,
  package: 'egg-graphql',
};